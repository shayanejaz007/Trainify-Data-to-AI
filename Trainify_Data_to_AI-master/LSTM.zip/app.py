from LSTM import model_run, predict_text
from flask import Flask, request, jsonify, url_for, send_file
import csv

app = Flask(__name__)


@app.route('/download_model_file/<user_id>', methods=["GET"])
def download_model_file(user_id):
    try:
        file_path = f"User_Data/{user_id}_model.h5"
        if file_path is None:
            return "File not found", 404
        return send_file(file_path, as_attachment=True, download_name=f"{user_id}_model.h5")
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route('/download_label_encoder_file/<user_id>', methods=["GET"])
def download_label_encoder_file(user_id):
    try:
        file_path = f"User_Data/{user_id}_label_encoder.pkl"
        if file_path is None:
            return "File not found", 404
        return send_file(file_path, as_attachment=True, download_name=f"{user_id}_label_encoder.pkl")
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route('/download_tokenizer_file/<user_id>', methods=["GET"])
def download_tokenizer_file(user_id):
    try:
        file_path = f"User_Data/{user_id}_tokenizer.pkl"
        if file_path is None:
            return "File not found", 404
        return send_file(file_path, as_attachment=True, download_name=f"{user_id}_tokenizer.pkl")
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route('/train', methods=['POST'])
# Example usage
def train():
    try:

        path = request.files['file']
        target = request.form.get('target_column')
        epochs = request.form.get("epochs")
        user_id = request.form.get("user_id")

        # path = "spam_ham_dataset.csv"  # Replace with your CSV file path
        # target = "label"  # Replace with the name of your label column
        # epochs = 15
        accuracy, report, classes = model_run(user_id, path, target, int(epochs))
        # print("Accuracy :", accuracy)
        # print("Report :", report)

        response = {
            "Accuracy": accuracy,
            "Report": report,
            "download_model": url_for('download_model_file', user_id=user_id,
                                      _external=True),
            "download_label_encoder": url_for('download_label_encoder_file', user_id=user_id,
                                              _external=True),
            "download_tokenizer": url_for('download_tokenizer_file', user_id=user_id,
                                          _external=True),
            "Classes": classes
        }

        return jsonify(response), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 400
        # print("error", e)


@app.route('/predict', methods=['POST'])
def predict():
    try:

        path = request.files['file']
        # model_save_path = "model.h5"
        # label_encoder_save_path = "label_encoder.pkl"
        # tokenizer_save_path = "tokenizer.pkl"

        model = request.files['model']
        label_encoder = request.files["label_encoder"]
        tokenizer = request.files["tokenizer"]
        print(label_encoder)
        print(tokenizer)

        lbl = predict_text(model, tokenizer, label_encoder, path)
        lbl = lbl.tolist()


        response = {
            "Results": lbl
        }
        return jsonify(response), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 400


if __name__ == "__main__":
    app.run(debug=True, port=8080)
    # train()
    # predict()
