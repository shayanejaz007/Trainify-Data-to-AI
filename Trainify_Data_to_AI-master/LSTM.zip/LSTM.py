import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout
from sklearn.preprocessing import LabelEncoder
from pathlib import Path
import csv
import pickle
import os
import h5py
from io import BytesIO

# Load data from CSV file
def load_data(user_id, file_path, label_column, save_tokenizer_path="tokenizer.pkl",
              save_label_encoder_path="label_encoder.pkl"):
    # Read CSV file and handle missing values
    df = pd.read_csv(file_path)
    classes = df.columns.tolist()
    # Select the remaining column as the text column
    text_column = [col for col in df.columns if col != label_column][0]

    # Clean and preprocess text data if needed (add more cleaning steps as necessary)
    df[text_column] = df[text_column].astype(str)
    df.dropna(subset=[text_column, label_column], inplace=True)  # Drop rows with missing values in text or label column
    df[text_column] = df[text_column].apply(lambda x: x.lower())  # Convert text to lowercase, for example

    texts = df[text_column].values
    labels = df[label_column].tolist()

    label_encoder = LabelEncoder()
    labels_numeric = label_encoder.fit_transform(labels)


    labels_directory = "User_Data"
    os.makedirs(labels_directory, exist_ok=True)

    tokenizer_path = os.path.join(labels_directory, f"{user_id}_{save_tokenizer_path}")
    # Save Tokenizer as pkl
    if save_tokenizer_path:
        tokenizer = Tokenizer(num_words=5000, oov_token='<OOV>')
        tokenizer.fit_on_texts(texts)
        with open(tokenizer_path, 'wb') as tokenizer_file:
            pickle.dump(tokenizer, tokenizer_file)

    LabelEncoder_path = os.path.join(labels_directory, f"{user_id}_{save_label_encoder_path}")
    # Save LabelEncoder as pkl
    if save_label_encoder_path:
        with open(LabelEncoder_path, 'wb') as le_file:
            pickle.dump(label_encoder, le_file)

    return texts, labels_numeric, classes


def preprocess_text(texts, max_words, max_len):
    tokenizer = Tokenizer(num_words=max_words, oov_token='<OOV>')
    tokenizer.fit_on_texts(texts)
    sequences = tokenizer.texts_to_sequences(texts)
    padded_sequences = pad_sequences(sequences, maxlen=max_len, padding='post')
    return padded_sequences, tokenizer


# Build LSTM model
def build_lstm_model(max_words, embedding_dim, lstm_units, max_len):
    model = Sequential()
    model.add(Embedding(input_dim=max_words, output_dim=embedding_dim, input_length=max_len))
    model.add(LSTM(units=lstm_units))
    model.add(Dense(units=256, activation='relu'))
    model.add(Dropout(0.2))
    model.add(Dense(units=1, activation='sigmoid'))
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model


# Train and evaluate the model
def train_and_evaluate_model(user_id, texts, labels, epochs, max_words=5000, embedding_dim=32, lstm_units=32, max_len=100,
                             test_size=0.2, save_model_path="model.h5"):

    X_train, X_test, y_train, y_test = train_test_split(texts, labels, test_size=test_size, random_state=42)

    X_train_pad, tokenizer = preprocess_text(X_train, max_words, max_len)
    X_test_pad = pad_sequences(tokenizer.texts_to_sequences(X_test), maxlen=max_len, padding='post')

    model = build_lstm_model(max_words, embedding_dim, lstm_units, max_len)

    model.fit(X_train_pad, y_train, epochs=epochs, validation_data=(X_test_pad, y_test))


    labels_directory = "User_Data"
    model_path = os.path.join(labels_directory, f"{user_id}_{save_model_path}")
    # Save the model if save_model_path is provided
    if save_model_path:
        model.save(model_path)

    # Evaluate the model
    y_pred = (model.predict(X_test_pad) > 0.5).astype(int)
    accuracy = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred)

    return accuracy, report


# Prediction function
def predict_text(model_path, tokenizer_path, label_encoder_path, csv_file_path, max_len=100):
    text_samples = []
    df = pd.read_csv(csv_file_path)
    text_samples = df.iloc[:, 0].dropna().astype(str).tolist()    

    #with open(tokenizer_path, 'rb') as tokenizer_file:
    tokenizer = pickle.load(tokenizer_path)



    sequences = tokenizer.texts_to_sequences(text_samples)
    padded_sequences = pad_sequences(sequences, maxlen=max_len, padding='post')


    file_content = model_path.read()
    file_like_object = BytesIO(file_content)
    with h5py.File(file_like_object, 'r') as f:
        loaded_model = load_model(f)
    predictions = (loaded_model.predict(padded_sequences) > 0.5).astype(int)

    # Inverse transform the numeric labels back to original labels
    #with open(label_encoder_path, 'rb') as le_file:
    label_encoder = pickle.load(label_encoder_path)

    predicted_labels = label_encoder.inverse_transform(predictions.flatten())

    return predicted_labels


def model_run(user_id, path, label, epochs):
    # FILES - INPUTS - OUTPUTS
    file_path = path
    label_column = label
    # TRAINING
    texts, labels, classes = load_data(user_id, file_path, label_column)
    accuracy, report = train_and_evaluate_model(user_id, texts, labels, epochs)
    # EVALUATION
    return accuracy, report, classes
